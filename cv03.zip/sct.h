/*
 * sct.h
 *
 *  Created on: 15. 10. 2020
 *      Author: Martin Košút
 */

#ifndef SCT_H_
#define SCT_H_

void sct_led(uint32_t value);
void sct_init(void);
void sct_value(uint16_t value);

#endif /* SCT_H_ */
